import axios from 'axios';

const URL = "http://localhost:8282/questions";

class PolicyQuestionsService {
    getPolicyQuestions() {
        return axios.get(URL);
    }

    addPolicyQuestions(questions) {
        return axios.post(URL,questions)
    }
}

export default new PolicyQuestionsService();