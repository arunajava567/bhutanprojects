import React, { Component } from 'react';
import { connect } from 'react-redux';
import * as LoginAction from '../store/actions/LoginAction';
import { bindActionCreators } from 'redux';
import { Link } from 'react-router-dom';

class LoginComponent extends Component {
	constructor(props) {
		super(props)
		this.state = {
			username: '',
			password: ''
		}
		//  this.onChange = this.onChange.bind(this);
		// this.saveUser = this.saveUser.bind(this);
	}

	saveUser = (e) => {
		let payload = {
			username: this.state.username,
			password: this.state.password
		}
		this.props.LoginAction.doLogin(payload);// this step was missing in previous demo
		e.preventDefault();	

	}
	onChange = (e) => this.setState({ [e.target.name]: e.target.value });

	render() {

		let userRole = this.props.userrole;

		if (userRole !== undefined) {
			console.log(userRole);
			if (userRole.role === "admin") {
				this.props.history.push("/admin");
			}
			else if (userRole.role === "agent") {
				this.props.history.push("/agent");
			}
			else {
				alert("Invalid user .. try again");
				this.props.history.push("/login");
			}
		}

			return (
				<div>
					<h1>Login Page</h1>
					<form >
						<div className="form-group">
							<label>Username</label>
							<input type="text" name="username" className="form-control" value={this.state.username} onChange={this.onChange} required></input><br></br>
							<label>Password</label>
							<input type="text" name="password" className="form-control" value={this.state.password} onChange={this.onChange} required></input><br></br>
						</div>
						<button className="btn btn-success" onClick={this.saveUser}>Login</button>

						<Link to="/segments"><h4>New User Registration</h4></Link>
					</form>
				</div>
			);
		}
	}


function mapStateToProps(state) {
    return {
		userrole: state.LoginReducer.userrole
	};
}


function mapDispatchToProps(dispatch) {
	return {
		LoginAction: bindActionCreators(LoginAction, dispatch)
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(LoginComponent);