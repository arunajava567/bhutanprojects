import React, { Component } from 'react';
import PolicyQuestionsService from '../service/PolicyQuestionsService';
import { connect } from 'react-redux';

class ListPolicyQuestionsComponent extends Component {
    constructor(props){
        super(props)
        this.state = {
            questions : [],
            message : null
        }
        this.reloadPolicyQuestionsList = this.reloadPolicyQuestionsList.bind(this);
        this.addQuestions = this.addQuestions.bind(this);
    }
    componentDidMount() {
        this.reloadPolicyQuestionsList();
    }

    reloadPolicyQuestionsList() {
        PolicyQuestionsService.getPolicyQuestions().then((Response)=>{
            this.setState({questions: Response.data})
        } );

    }

    addQuestions(){
        window.localStorage.removeItem("pol_ques_id");
        this.props.history.push("/addquestions");
    }

    onClick() {
        window.location.href="/segments"
    }
    render() {
        let userRole = this.props.userrole;
        	
        return(
            <div>
                 <table className="table table-striped">
                    <caption><h1 align="center">Insurance Quote Registration </h1></caption>
                    <caption><h2 align="center">Policy Questions List</h2></caption>
                    <thead>
                       <tr>
                            <th>QUES_ID</th>
                            <th>QUESTION_DESCRIPTION</th>
                            <th>SEQUENCE</th>
                            <th>ANSWER_1</th>
                            <th>WEIGHTAGE_1</th>
                            <th>ANSWER_2</th>
                            <th>WEIGHTAGE_2</th>
                            <th>ANSWER_3</th>
                            <th>WEIGHTAGE_3</th>
                            <th>SEGMENT_ID</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.questions.map(
                                ques=>
                                <tr key={ques.pol_ques_id}>
                                    <td align="center">{ques.pol_ques_id}</td>
                                    <td>{ques.pol_ques_desc}</td>
                                    <td>{ques.pol_ques_seq}</td>
                                    <td>{ques.pol_ques_ans1}</td>
                                    <td align="center">{ques.pol_ques_ans1_weightage}</td>
                                    <td>{ques.pol_ques_ans2}</td>
                                    <td align="center">{ques.pol_ques_ans2_weightage}</td>
                                    <td>{ques.pol_ques_ans3}</td>
                                    <td align="center">{ques.pol_ques_ans3_weightage}</td>
                                    <td align="center">{ques.businessSegment.bus_seg_id}</td>
                                    
                                    { (userRole !== undefined) &&
                                       (userRole.role === "admin") ?
                                          <React.Fragment></React.Fragment>
                                          :
                                          <React.Fragment>
                                            <td> <button className="btn btn-warning" >Update</button></td>
                                            <td><button className="btn btn-danger" >Delete</button></td>
                                          </React.Fragment> 
                                    }
                               </tr>
                            )
                        }
                    </tbody>
                </table>
                <button className="btn btn-primary" onClick={()=>this.addQuestions()}>Add Question</button>
                <button className="btn btn-link" id="bt" onClick={this.onClick}><h4>View Segments</h4></button>
            </div>
        );
    }
}


function mapStateToProps(state) {
    return {
		userrole: state.LoginReducer.userrole
	};
}

export default connect(mapStateToProps, null)(ListPolicyQuestionsComponent);