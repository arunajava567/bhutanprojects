import React, { Component } from 'react';
import { connect } from 'react-redux';

class AdminComponent extends Component {
    
    onClick() {
        window.location.href="/questions"
    }
    render(){
        return(
            <div>
                
                <h1>Welcome Administrator </h1>
                 <button className="btn btn-link" id="bt" onClick={this.onClick}><h4>View Questions</h4></button>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
		userrole: state.LoginReducer.userrole
	};
}
export default connect(mapStateToProps, null)(AdminComponent);