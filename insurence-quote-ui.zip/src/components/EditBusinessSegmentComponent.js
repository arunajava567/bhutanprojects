import React, { Component } from 'react';
import BusinessSegmentService from '../service/BusinessSegmentService';

class EditBusinessSegmentComponent extends Component {
    constructor(props){
        super(props)
        this.state = {
            bus_seg_id : '',
            bus_seg_seq : '',
            bus_seg_name : ''
        }
        this.saveSegment = this.saveSegment.bind(this);
        this.loadSegment = this.loadSegment.bind(this);
    }
    componentDidMount(){
        this.loadSegment();
    }
    loadSegment() {
        BusinessSegmentService.getSegmentById(window.localStorage.getItem("seg_id"))
        .then((Response) => {
            let segment = Response.data;
            this.setState({
                bus_seg_id : segment.bus_seg_id,
                bus_seg_seq : segment.bus_seg_seq,
                bus_seg_name : segment.bus_seg_name
            })
        });
    }

    onChange = (seg) => this.setState({[seg.target.name] : seg.target.value});
    saveSegment = (seg) => {
        seg.preventDefault();
        let segment = {
            bus_seg_id : this.state.bus_seg_id,
            bus_seg_seq : this.state.bus_seg_seq,
            bus_seg_name : this.state.bus_seg_name
        };
        BusinessSegmentService.editBusinessSegment(segment).then(res=> {
            this.setState({message : "Segment updated sucessfully"});
            this.props.history.push("/segments");
        });
    }

    render() {
        return(
            <div>
                <h1>Edit Business Segment</h1>
                <form>
                    <div className="form-group">
                        <label>Segment ID</label>
                        <input type="text" name="bus_seg_id" className="form-control" value={this.state.bus_seg_id} onChange={this.onChange} readOnly></input><br></br>
                        <label>Segment SEQ</label>
                        <input type="text" name="bus_seg_seq" className="form-control" value={this.state.bus_seg_seq} onChange={this.onChange}></input><br></br>
                        <label>Segment NAME</label>
                        <input type="text" name="bus_seg_name" className="form-control" value={this.state.bus_seg_name} onChange={this.onChange}></input><br></br>
                    </div>
                    <button className="btn btn-success" onClick={this.saveSegment}>Save</button>
                </form>
            </div>
        );
    }
}

export default EditBusinessSegmentComponent;