import React, { Component } from 'react';

class AgentComponent extends Component {
    onClick() {
        window.location.href="/questions"
    }
    render() {
        return(
            <div>
                <h1>Welcome Agent Home Page</h1>
                <button className="btn btn-link" id="bt" onClick={this.onClick}><h4>View Questions</h4></button>
            </div>
        );
    }
}

export default AgentComponent;