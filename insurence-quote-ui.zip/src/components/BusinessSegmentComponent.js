import React, { Component } from 'react';
import BusinessSegmentService from '../service/BusinessSegmentService';

class BusinessSegmentComponent extends Component {
    constructor(props) {
    super(props) 
    this.state = {
        segments : [],
        message : null
    }
    this.reloadBusinessSegmentsList = this.reloadBusinessSegmentsList.bind(this);
    this.addSegment = this.addSegment.bind(this);
    this.editSegment = this.editSegment.bind(this);
    this.deleteSegment = this.deleteSegment.bind(this);
    }

    componentDidMount() {
        this.reloadBusinessSegmentsList();
    }
    reloadBusinessSegmentsList() {
        BusinessSegmentService.getBusinessSegments().then((Response)=>{
            this.setState({segments : Response.data})
        });
    }
    addSegment() {
        window.localStorage.removeItem("bus_seg_id");
        this.props.history.push("/addsegment");
    }

    editSegment(seg_id) {
        window.localStorage.setItem("seg_id",seg_id);
        this.props.history.push("/editsegment");
    }

    deleteSegment(seg_id){
        BusinessSegmentService.deleteBusinessSegement(seg_id).then((res)=> {
            this.setState({message : "segment deleted"});
            this.setState({segments : this.state.segments.filter(segment=>segment.bus_seg_id !== seg_id)});
        } );
    }
    onClick() {
        window.location.href="/questions"
    }
    render() {
        return(
            <div>
                <button className="btn btn-link" id="bt" onClick={this.onClick}> &lt;&lt;Back</button>
                <table className="table table-striped">
                
                <caption><h1 align="center">Insurance Quote Registration </h1></caption>
                <caption><h2 align="center">Business Segments List</h2></caption>
                <thead>
                    <tr>
                        <th>SEG ID</th>
                        <th>SEG SEQ</th>
                        <th>SEGMENT NAME</th>
                    </tr>
                    <tbody>
                        {
                            this.state.segments.map(
                                seg=>
                                <tr key={seg.bus_seg_id}>
                                <td>{seg.bus_seg_id}</td>        
                                <td>{seg.bus_seg_seq}</td>
                                <td>{seg.bus_seg_name}</td>
                                
                                <td>
                                    <button className="btn btn-warning" onClick={()=>this.editSegment(seg.bus_seg_id)}>Edit</button>
                                </td>
                                <td>
                                    <button className="btn btn-success" onClick={()=>this.deleteSegment(seg.bus_seg_id)}>Del</button>
                                </td>
                                </tr>
                            )
                        }
                    </tbody>
                </thead>
                </table>
                <button className="btn btn-primary" onClick={()=>this.addSegment()}>Add Segment</button>
            </div>
        );
    }
}

export default BusinessSegmentComponent;
