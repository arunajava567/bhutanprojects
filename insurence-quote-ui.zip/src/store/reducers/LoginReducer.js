const initialState = {
    userrole : undefined
}

export default function LoginReducer(state = initialState, action) {
    switch (action.type) {
        case 'LOGIN_SUCCESS':
            return{
                ...state,
                userrole: action.userrole
            };
            
        default:
            return state
    }
};
