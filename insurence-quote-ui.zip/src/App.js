import React from 'react';
import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import ListPolicyQuestionsComponent from './components/ListPolicyQuestionsComponent';
import BusinessSegmentComponent from './components/BusinessSegmentComponent'
import AddBusiSegmentComponent from './components/AddBusiSegmentComponent';
import EditBusinessSegmentComponent from './components/EditBusinessSegmentComponent';
import AddPolicyQuestionsComponent from './components/AddPolicyQuestionsComponent';
import LoginComponent from './components/LoginComponent';
import AdminComponent from './components/AdminComponent';
import AgentComponent from './components/AgentComponent';
function App() {
  return (
    <div className="container">
      <Router>
        <div className="col-md-6">
          <Switch>
            {/* <Route path="/" exact component={ListPolicyQuestionsComponent}></Route> */}
            <Route path="/" exact component={LoginComponent}></Route>
            <Route path="/login" exact component={LoginComponent}></Route>
            <Route path="/questions" exact component={ListPolicyQuestionsComponent}></Route>
            <Route path="/segments" exact component={BusinessSegmentComponent}></Route>
            <Route path="/addsegment" exact component={AddBusiSegmentComponent}></Route>
            <Route path="/editsegment" exact component={EditBusinessSegmentComponent}></Route>
            <Route path="/addquestions" exact component={AddPolicyQuestionsComponent}></Route>
            <Route path="/admin" exact component={AdminComponent}></Route>
            <Route path="/agent" exact component={AgentComponent}></Route>
          </Switch>
        </div>
      </Router>
    </div>
  );
}

export default App;
