import React, { Component } from 'react'
import EmployeeService from '../services/EmployeeService';

class CreateEmployeeComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            // step 2
            candidateId:this.props.match.params.candidateId,
            candidateName:'',
            primarySkill:'',
            secondarySkill:'',
            experience:'',
            qualification:'',
            designation:'',
            noticePeriod:'',
            location:''
           // id: this.props.match.params.id,
            //firstName: '',
            //lastName: '',
            //type: '',
            //schedule: ''
        }
        this.changeCandidateNameHandler = this.changeCandidateNameHandler.bind(this);
        this.changePrimarySkillHandler = this.changePrimarySkillHandler.bind(this);
        this.changeSecondarySkillHandler = this.changeSecondarySkillHandler.bind(this);
        this.changeExperienceHandler = this.changeExperienceHandler.bind(this);
        this.changeQualificationHandler = this.changeQualificationHandler.bind(this);
        this.changeDesignationHandler = this.changeDesignationHandler.bind(this);
        this.changeNoticePeriodHandler = this.changeNoticePeriodHandler.bind(this);
        this.changeLocationHandler = this.changeLocationHandler.bind(this);
     
        this.saveOrUpdateEmployee = this.saveOrUpdateEmployee.bind(this);
    }

    // step 3
    componentDidMount(){

        // step 4
        if(this.state.candidateId === '_add'){
            return
        }else{
            EmployeeService.getEmployeeById(this.state.candidateId).then( (res) =>{
                let employee = res.data;
                this.setState({
                    candidateName:employee.candidateName,
                    primarySkill:employee.primarySkill,
                    secondarySkill:employee.secondarySkill,
                    experience:employee.experience,
                    qualification:employee.qualification,
                    designation:employee.designation,
                    noticePeriod:employee.noticePeriod,
                    location:employee.location

                   
                });
            });
        }        
    }
    saveOrUpdateEmployee = (e) => {
        e.preventDefault();
        let employee = {
            candidateName: this.state.candidateName, primarySkill: this.state.primarySkill, 
            secondarySkill: this.state.secondarySkill,
            experience: this.state.experience,
            qualification:this.state.qualification,
            designation:this.state.designation,
            noticePeriod:this.state.noticePeriod,
            location:this.state.location

        
        };
        console.log('employee => ' + JSON.stringify(employee));

        // step 5
        if(this.state.candidateId === '_add'){
            EmployeeService.createEmployee(employee).then(res =>{
                this.props.history.push('/employees');
            });
        }else{
            EmployeeService.updateEmployee(employee, this.state.idcandidateId).then( res => {
                this.props.history.push('/employees');
            });
        }
    }
    
    changeCandidateNameHandler= (event) => {
        this.setState({candidateName: event.target.value});
    }

    changePrimarySkillHandler= (event) => {
        this.setState({primarySkill: event.target.value});
    }
    changeSecondarySkillHandler= (event) => {
        this.setState({secondarySkill: event.target.value});
    }
    changeExperienceHandler= (event) => {
        this.setState({experience: event.target.value});
    }
    changeQualificationHandler= (event) => {
        this.setState({qualification: event.target.value});
    }
    changeDesignationHandler= (event) => {
        this.setState({designation: event.target.value});
    }
    changeNoticePeriodHandler= (event) => {
        this.setState({noticePeriod: event.target.value});
    }
    changeLocationHandler= (event) => {
        this.setState({location: event.target.value});
    }
    cancel(){
        this.props.history.push('/employees');
    }

    getTitle(){
        if(this.state.candidateId === '_add'){
            return <h3 className="text-center">Add Employee</h3>
        }else{
            return <h3 className="text-center">Update Employee</h3>
        }
    }
    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                {
                                    this.getTitle()
                                }
                                <div className = "card-body">
                                    <form>
                                        <div className = "form-group">
                                            <label> Candidate Name: </label>
                                            <input placeholder="Candidate Name" name="candidateName" className="form-control" 
                                                value={this.state.candidateName} onChange={this.changeCandidateNameHandler}/>
                                        </div>
                                       
                                        <div className = "form-group">
                                            <label> primarySkill: </label>
                                            <input placeholder="primarySkill" name="primarySkill" className="form-control" 
                                                value={this.state.primarySkill} onChange={this.changePrimarySkillHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> SecondarySkill: </label>
                                            <input placeholder="secondarySkill " name="secondarySkill" className="form-control" 
                                                value={this.state.secondarySkill} onChange={this.changeSecondarySkillHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Experience: </label>
                                            <input placeholder="experience " name="experience" className="form-control" 
                                                value={this.state.experience} onChange={this.changeExperienceHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> qualification: </label>
                                            <input placeholder="qualification " name="qualification" className="form-control" 
                                                value={this.state.qualification} onChange={this.changeQualificationHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Designation: </label>
                                            <input placeholder="designation " name="designation" className="form-control" 
                                                value={this.state.designation} onChange={this.changeDesignationHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> NoticePeriod: </label>
                                            <input placeholder="noticePeriod " name="noticePeriod" className="form-control" 
                                                value={this.state.noticePeriod} onChange={this.changeNoticePeriodHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Location: </label>
                                            <input placeholder="location" name="location" className="form-control" 
                                                value={this.state.location} onChange={this.changeLocationHandler}/>
                                        </div>


                                        <button className="btn btn-success" onClick={this.saveOrUpdateEmployee}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
        )
    }
}

export default CreateEmployeeComponent
