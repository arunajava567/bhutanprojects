import React, { Component } from 'react'
import EmployeeService from '../services/EmployeeService'

class ViewEmployeeComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            candidateId: this.props.match.params.candidateId,
            employee: {}
        }
    }

    componentDidMount(){
        EmployeeService.getEmployeeById(this.state.candidateId).then( res => {
            this.setState({employee: res.data});
        })
    }
/* candidateName:'',
            primarySkill:'',
            secondarySkill:'',
            experience:'',
            qualification:'',
            designation:'',
            noticePeriod:'',
            location:''*/
    render() {
        return (
            <div>
                <br></br>
                <div className = "card col-md-6 offset-md-3">
                    <h3 className = "text-center"> View Employee Details</h3>
                    <div className = "card-body">
                        <div className = "row">
                            <label> Candidate Name: </label>
                            <div> { this.state.employee.candidateName }</div>
                        </div>
                        <div className = "row">
                            <label> PrimarySkills: </label>
                            <div> { this.state.employee.primarySkill }</div>
                        </div>
                        <div className = "row">
                            <label> SecondarySkill: </label>
                            <div> { this.state.employee.secondarySkill }</div>
                        </div>
                        <div className = "row">
                            <label> Experience: </label>
                            <div> { this.state.employee.experience }</div>
                        </div>
                        <div className = "row">
                            <label> Qualification: </label>
                            <div> { this.state.employee.qualification }</div>
                        </div>
                        <div className = "row">
                            <label> Designation: </label>
                            <div> { this.state.employee.designation }</div>
                        </div>
                        <div className = "row">
                            <label> NoticePeriod: </label>
                            <div> { this.state.employee.noticePeriod }</div>
                        </div>
                        <div className = "row">
                            <label> Location: </label>
                            <div> { this.state.employee.location }</div>
                        </div>
                    </div>

                </div>
            </div>
        )
    }
}

export default ViewEmployeeComponent
